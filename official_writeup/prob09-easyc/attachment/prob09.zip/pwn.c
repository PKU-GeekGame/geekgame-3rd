#include<stdio.h>
#include<string.h>
#include<unistd.h>

void test()
{
    char buf[1024];
    char secrets[64]="a_very_secret_string";
    int secreti1=114514,secreti2=1919810;
    char publics[64]="a_public_string";
    int publici=0xdeadbeef;
    char flag1[64]="a_flag";
    FILE* fp=fopen("flag_f503be2d","r");
    fgets(flag1,63,fp);
    fclose(fp);
    //get flag2 in another file
    while(1)
    {
        printf("Please input your instruction:\n");
        fgets(buf,1023,stdin);
        if(memcmp(buf,"exit",4)==0)
            break;
        int t=printf(buf,publics,publici);
        if(t>1024)
        {
            printf("Too long!\n");
            break;
        }
        printf("\n");
    }
}

int main()
{
    setvbuf(stdin, 0, 2, 0);
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stderr, 0, 2, 0);
    test();
    return 0;
}

//gcc pwn.c -o pwn -static-pie