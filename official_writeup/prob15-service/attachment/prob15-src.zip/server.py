#!/usr/bin/python3
import subprocess
import shlex


def run(cmd):
    argv = shlex.split(cmd)
    pipe = subprocess.Popen(
        argv,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=False)
    status_output, error = pipe.communicate()
    return status_output.decode("utf-8")


print("|| Service Checker ||")
print("[*] LIST")
print("[*] STATUS")
print("[*] EXIT")

while True:
    command = input("Command: ")
    if command == "LIST":
        cmd = "/usr/sbin/service --status-all"
        print(run(cmd))
    elif command == "STATUS":
        service_name = input("Service name: ")
        cmd = "/usr/sbin/service {} status".format(service_name)
        print(run(cmd))
    elif command == "EXIT":
        break
    else:
        print("Unknown command...")

print("Bye Bye...")
