# pip3 install selenium
# you also need a chromedriver according to your chrome version, available at https://googlechromelabs.github.io/chrome-for-testing/#stable

from selenium import webdriver
import time
import re
from pathlib import Path
import shutil

try:
    from flag import getflag
except:
    def getflag(index):
        return [
            'fake{get-flag-1-from-the-real-xss-bot}',
            'fake{get-flag-2-from-the-real-xss-bot}',
        ][index-1]

try:
    hacker_url = input('Your blog URL: ')
    assert len(hacker_url)<=1000
    
    #match = re.match(r'^(https?)://([^/]+)/([/a-z0-9~_-]+)$', hacker_url)
    match = re.match(r'^(https?)://(prob99-[0-9a-z]{8}\.geekgame\.pku\.edu\.cn)/([/a-z0-9~_-]+)$', hacker_url)
    assert match is not None
    
    protocol, host, path = match.groups()
    admin_url = f'{protocol}://{host}/admin/'
    
    print('\nStarting up the browser...')
    
    data_path = Path('selenium_data').resolve()
    if data_path.is_dir():
        shutil.rmtree(data_path)
    data_path.mkdir()
    
    options = webdriver.ChromeOptions()
    options.add_argument('--no-sandbox') # sandbox not working in docker :(
    options.add_argument(f"user-data-dir={data_path}")
    options.add_experimental_option('excludeSwitches', ['enable-logging'])

    if protocol=='http': # flag 1
    
        with webdriver.Chrome(options=options) as driver:
            print('\nSetting up flag 1')
            driver.get(admin_url)
            time.sleep(.5)
            driver.execute_script(f'document.cookie = "flag={getflag(1)}; path=/admin"')
            time.sleep(.5)
           
            print('\nVisiting your webpage')
            driver.get(hacker_url)
            time.sleep(1)
            
            title = driver.title
            print('\nThe page title is:', title)
            
    else: # https, flag 2
        
        with webdriver.Chrome(options=options) as driver:
            print('\nVisiting your webpage')
            driver.get(hacker_url)
            time.sleep(1)
            
        with webdriver.Chrome(options=options) as driver:
            print('\nSetting up flag 2')
            driver.get(admin_url)
            time.sleep(.5)
            driver.execute_script(f'document.cookie = "flag={getflag(2)}; path=/admin"')
            time.sleep(1)
        
            title = driver.title
            print('\nThe page title is:', title)
        
    print('\nSee you later :)')
    
except Exception as e:
    print('ERROR', type(e))
    #raise