import subprocess
import string

N = 18

ELEMENTS = {
    'WIRER': [
        "-xX-",
    ],
    'WIREC': [
        "-",
        "x",
        "X",
        "-",
    ],
    'WALL': [
        '12321',
        '1***1',
        '13x31',
        '.1X1.',
        '..-..',
    ],
    'CORNER':
    [
        '..-.',
        '..X.',
        '..x.',
        '.**1',
        '-xX*',
        '...*'
    ],
    'NOT': [
        "1121211",
        "2*3*3*2",
        "-x5X5x-",
        "2*3*3*2",
        "1121211",
    ],
    'SPLIT': [
        '.12-21...',
        '.1*x*1...',
        '123321**.',
        '2*3X111x-',
        '3*x2x1X1.',
        '2*3X11**.',
        '112-1....',
    ],
    "AND": [  # or nand
        '.1233321..',
        '13*****31.',
        '2**bcd**2.',
        '2*A334z*31',
        '23422*33*1',
        '2*a*322Z22',
        '-x6zZ1z2z-',
        '2*y*223Z32',
        '12-211***1',
        '.....12321',
    ]
}


class ElementTemplate:
    def __init__(self, template):
        self.tid = template
        self.template = ELEMENTS[template]*1
        self.assigned = False
        self.size = (len(self.template), len(self.template[0]))

    def assign(self, k, v):
        assert len(k) == 1
        assert k in string.ascii_lowercase
        assert str.islower(k)
        assert v in [0, 1]
        for i in range(len(self.template)):
            self.template[i] = self.template[i].replace(k, "0*"[v])
            self.template[i] = self.template[i].replace(k.upper(), "0*"[1-v])

    def assignCircuit(self, asn):
        self.assigned = True
        if self.tid == 'WIRER':
            return self.assign('x', asn['x'])
        if self.tid == 'WIREC':
            return self.assign('x', asn['x'])
        if self.tid == 'CORNER':
            return self.assign('x', asn['x'])
        if self.tid == 'WALL':
            return self.assign('x', asn['x'])
        if self.tid == 'NOT':
            return self.assign('x', asn['x'])
        if self.tid == 'SPLIT':
            return self.assign('x', asn['x'])
        if self.tid == 'AND':
            x = asn['x']
            y = asn['y']
            z = 1-(x & y)
            a = 2-x-y-z
            b = z
            d = 1-a
            c = 2-b-d
            self.assign('x', x)
            self.assign('y', y)
            self.assign('z', z)
            self.assign('a', a)
            self.assign('b', b)
            self.assign('c', c)
            self.assign('d', d)
            return
        assert False


class ElementObject:
    def __init__(self, template):
        self.template = ElementTemplate(template)

    def assign(self, asn):
        self.template.assignCircuit(asn)

    def place(self, board, bx, by):
        assert self.template.assigned
        for i in range(self.template.size[0]):
            for j in range(self.template.size[1]):
                x, y = bx+i, by+j
                gird = board.get(x, y)
                if self.template.template[i][j] == '.':
                    continue
                if self.template.template[i][j] == '-':
                    # assert gird.isWireFree()
                    gird.objs.append(GirdWireCross(gird))
                    continue
                if self.template.tid in ["WIREC", "WIRER"]:
                    assert gird.isWireFree()
                else:
                    assert gird.isFree()
                if self.template.template[i][j] == '*':
                    gird.objs.append(GirdBomb(gird))
                    continue
                if self.template.template[i][j] in "012345678":
                    gird.objs.append(GirdUsed(gird))
                    continue
                assert False


class GirdObject:
    def __init__(self, element):
        self.element = element
        self.type = None


class GirdWireCross(GirdObject):
    def __init__(self, element):
        super().__init__(element)
        self.type = 'WIREB'


class GirdBomb(GirdObject):
    def __init__(self, element):
        super().__init__(element)
        self.type = 'BOMB'


class GirdUsed(GirdObject):
    def __init__(self, element):
        super().__init__(element)
        self.type = 'USED'


class Grid:
    def __init__(self, x, y):
        self.objs = []
        self.x = x
        self.y = y

    def isFree(self):
        return len(self.objs) == 0

    def isWireFree(self):
        for obj in self.objs:
            if not isinstance(obj, GirdWireCross):
                return False
        return True

    def isBomb(self):
        for obj in self.objs:
            if obj.type == 'BOMB':
                return True
        return False

    def toStr(self):
        return '*' if self.isBomb() else '.'


class Board:
    def __init__(self):
        self.girds = {}
        self.size = None

    def get(self, x, y):
        if (x, y) not in self.girds:
            self.girds[(x, y)] = Grid(x, y)
        return self.girds[(x, y)]

    def gen(self):
        assert len(self.girds) == 0
        SSIGLEN = 6
        sats = Constraints()
        print(sats.solution)
        for i in range(sats.n):
            nv = ElementObject('WALL')
            nv.assign({'x': sats.solution[i]})
            nv.place(self, 1, i*SSIGLEN+3)
        toty = 5
        for i in range(len(sats.constraints)):
            print(sats.constraints[i], sats.solution[abs(sats.constraints[i][0])-1], sats.solution[abs(
                sats.constraints[i][1])-1], sats.solution[abs(sats.constraints[i][2])-1])
            for j in range(sats.n):
                nv = ElementObject('WIREC')
                nv.assign({'x': sats.solution[j]})
                nv.place(self, toty, j*SSIGLEN+5)

            def makewire(basey, x, idx):
                for j in range(sats.n):
                    if j+1 == abs(x):
                        nv = ElementObject('SPLIT')
                        nv.assign({'x': sats.solution[j]})
                        nv.place(self, basey, j*SSIGLEN+5-3)
                        for k in range(j+1, sats.n):
                            nv = ElementObject('WIRER')
                            nv.assign({'x': not sats.solution[j]})
                            nv.place(self, basey+3, k*SSIGLEN+4)
                            nv = ElementObject('WIRER')
                            nv.assign({'x': not sats.solution[j]})
                            nv.place(self, basey+3, k*SSIGLEN+4+3)
                    else:
                        nv = ElementObject('WIREC')
                        nv.assign({'x': sats.solution[j]})
                        nv.place(self, basey, j*SSIGLEN+5)
                        nv = ElementObject('WIREC')
                        nv.assign({'x': sats.solution[j]})
                        nv.place(self, basey+3, j*SSIGLEN+5)
                xv = sats.solution[abs(x)-1]
                iv = None
                nv = ElementObject('WIRER')
                nv.assign({'x': not xv})
                nv.place(self, basey+3, sats.n*SSIGLEN+4)
                if x < 0:
                    nv = ElementObject('NOT')
                    nv.assign({'x': not xv})
                    nv.place(self, basey+1, sats.n*SSIGLEN+4+3)
                    iv = xv
                else:
                    nv = ElementObject('WIRER')
                    nv.assign({'x': not xv})
                    nv.place(self, basey+3, sats.n*SSIGLEN+4+3)
                    nv = ElementObject('WIRER')
                    nv.assign({'x': not xv})
                    nv.place(self, basey+3, sats.n*SSIGLEN+4+6)
                    iv = not xv
                nv = ElementObject('WIRER')
                nv.assign({'x': iv})
                nv.place(self, basey+3, sats.n*SSIGLEN+4+9)
                return iv
            ai1 = makewire(toty+3, sats.constraints[i][0], 0)
            ai2 = makewire(toty+9, sats.constraints[i][1], 1)
            ai3 = makewire(toty+15, sats.constraints[i][2], 2)

            nv = ElementObject('AND')
            nv.assign({'x': ai1, 'y': ai2})
            nv.place(self, toty+3+3-6, sats.n*SSIGLEN+4+12)
            nv = ElementObject('CORNER')
            nv.assign({'x': ai2})
            nv.place(self, toty+3+3+6-4, sats.n*SSIGLEN+4+12)
            retv = ai1 & ai2
            nv = ElementObject('WIRER')
            nv.assign({'x': retv})
            nv.place(self, toty+3+3, sats.n*SSIGLEN+4+12+9)

            nv = ElementObject('AND')
            nv.assign({'x': retv, 'y': ai3})
            nv.place(self, toty+3+3-6, sats.n*SSIGLEN+4+12+12)
            for ts in range(4):
                nv = ElementObject('WIRER')
                nv.assign({'x': ai3})
                nv.place(self, toty+3+3+12, sats.n*SSIGLEN+4+12+3*ts)
            nv = ElementObject('CORNER')
            nv.assign({'x': ai3})
            nv.place(self, toty+3+3+12-4, sats.n*SSIGLEN+4+12+12)
            nv=ElementObject('WIREC')
            nv.assign({'x': not ai3})
            nv.place(self, toty+3+3+6-1, sats.n*SSIGLEN+4+12+12+2)
            nv=ElementObject('WIREC')
            nv.assign({'x': not ai3})
            nv.place(self, toty+3+3+3-1, sats.n*SSIGLEN+4+12+12+2)
            retv2 = retv & ai3
            nv = ElementObject('WIRER')
            nv.assign({'x': retv2})
            nv.place(self, toty+3+3, sats.n*SSIGLEN+4+12+12+9)

            toty += 3+6*3
        self.size = (toty, sats.n*SSIGLEN+45)

    def toStr(self):
        points = []
        for i in range(self.size[0]):
            rs = ""
            for j in range(self.size[1]):
                gird = self.get(i, j)
                rs += gird.toStr()
            points.append(rs)
        return points


class Constraints:
    def __init__(self):
        self.constraints = []
        self.solution = []
        self.gen()

    def gen(self):
        raw = subprocess.check_output(['./gensat']).decode()
        lns = raw.strip().split('\n')
        n, m = map(int, lns[0].split())
        assert n == N
        assert len(lns) == m+2
        self.n = n
        # 3sat
        for i in range(1, m+1):
            ln = lns[i].split()
            assert len(ln) == 4
            assert ln[3] == '0'
            self.constraints.append((int(ln[0]), int(ln[1]), int(ln[2])))
        # solution
        ln = lns[-1].split()
        assert len(ln) == n
        for i in range(n):
            self.solution.append(int(ln[i]))

    def __str__(self):
        return '\n'.join(map(lambda x: ' '.join(map(str, x)), self.constraints))


def gen():
    x = Constraints()


if __name__ == '__main__':
    gen()
