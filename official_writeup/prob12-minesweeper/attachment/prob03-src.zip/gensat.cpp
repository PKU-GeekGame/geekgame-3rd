#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<random>
#include<set>

using namespace std;

const int N=18;

int abs(int x)
{
    return x>0?x:-x;
}

int sgn(int x)
{
    return x>0?1:-1;
}

class Constraints
{
    public:
    struct Constraint
    {
        int a,b,c;
    }cs[200];
    int tot=0;
    set<int> solves;

    void insertConstraint(int a,int b,int c)
    {
        cs[tot++]={a,b,c};
    }

    bool calcSat(int* s)
    {
        for(int i=0;i<tot;i++)
        {
            int a=cs[i].a;
            if(sgn(a)==s[abs(a)])
                continue;
            int b=cs[i].b;
            if(sgn(b)==s[abs(b)])
                continue;
            int c=cs[i].c;
            if(sgn(c)==s[abs(c)])
                continue;
            return false;
        }
        return true;
    }

    void initSolver()
    {
        for(int i=0;i<(1<<N);i++)
        {
            int s[N+1];
            for(int j=1;j<=N;j++)
                s[j]=((i>>(j-1))&1)?1:-1;
            if(calcSat(s))
                solves.insert(i);
        }
    }

    int calcConstraint(int na,int nb,int nc)
    {
        int cnt=0;
        for(auto i:solves)
        {
            int a=((i>>(abs(na)-1))&1)?1:-1;
            int b=((i>>(abs(nb)-1))&1)?1:-1;
            int c=((i>>(abs(nc)-1))&1)?1:-1;
            if(sgn(a)==sgn(na) || sgn(b)==sgn(nb) || sgn(c)==sgn(nc))
                cnt++;
        }
        return cnt;
    }

    bool checkConstraint(int na,int nb,int nc)
    {
        int nsize=calcConstraint(na,nb,nc);
        return nsize!=solves.size() && nsize!=0;
    }

    void addConstraint(int na,int nb,int nc)
    {
        set<int> nsolves;
        for(auto i:solves)
        {
            int a=((i>>(abs(na)-1))&1)?1:-1;
            int b=((i>>(abs(nb)-1))&1)?1:-1;
            int c=((i>>(abs(nc)-1))&1)?1:-1;
            if(sgn(a)==sgn(na) || sgn(b)==sgn(nb) || sgn(c)==sgn(nc))
                nsolves.insert(i);
        }
        solves=nsolves;
        insertConstraint(na,nb,nc);
    }
}g;

int main()
{
    std::random_device rd;
    std::mt19937 rng(rd());
    std::uniform_int_distribution<> bdist(0, 1);
    std::uniform_int_distribution<> ndist(1, N);
    
    for(int i=0;i<(N+1)/2;i++)
    {
        int a=ndist(rng);
        int b=ndist(rng);
        int c=ndist(rng);
        while(a==b)
            b=ndist(rng);
        while(a==c || b==c)
            c=ndist(rng);
        if(a>b)
            swap(a,b);
        if(a>c)
            swap(a,c);
        if(b>c)
            swap(b,c);
        int sa=a*(bdist(rng)?1:-1);
        int sb=b*(bdist(rng)?1:-1);
        int sc=c*(bdist(rng)?1:-1);
        g.insertConstraint(sa,sb,sc);
    }
    g.initSolver();

    while(g.solves.size()!=1)
    {
        while(1)
        {
            int a=ndist(rng);
            int b=ndist(rng);
            int c=ndist(rng);
            while(a==b)
                b=ndist(rng);
            while(a==c || b==c)
                c=ndist(rng);
            if(a>b)
                swap(a,b);
            if(a>c)
                swap(a,c);
            if(b>c)
                swap(b,c);
            int sa=a*(bdist(rng)?1:-1);
            int sb=b*(bdist(rng)?1:-1);
            int sc=c*(bdist(rng)?1:-1);
            if(g.checkConstraint(sa,sb,sc))
            {
                g.addConstraint(sa,sb,sc);
                break;
            }
        }
        // cout<<g.tot<<' '<<g.solves.size()<<endl;
    }
    //clean
    int itts=0;
    while(itts<g.tot)
    {
        Constraints ng=Constraints();
        for(int i=0;i<g.tot;i++)
        {
            if(i==itts)
                continue;
            ng.insertConstraint(g.cs[i].a,g.cs[i].b,g.cs[i].c);
        }
        ng.initSolver();
        // cout<<itts<<' '<<g.tot<<' '<<ng.solves.size()<<endl;
        if(ng.solves.size()!=1)
        {
            itts++;
            continue;
        }
        g=ng;
    }
    //test
    Constraints ng=Constraints();
    for(int i=0;i<g.tot;i++)
    {
        ng.insertConstraint(g.cs[i].a,g.cs[i].b,g.cs[i].c);
    }
    ng.initSolver();
    if(ng.solves.size()!=1)
    {
        cout<<"Error!"<<endl;
        return -1;
    }
    // cout<<ng.tot<<' '<<ng.solves.size()<<endl;
    
    //out
    cout<<N<<' '<<g.tot<<endl;
    for(int i=0;i<g.tot;i++)
    {
        cout<<g.cs[i].a<<' '<<g.cs[i].b<<' '<<g.cs[i].c<<' '<<0<<endl;
    }

    //solution
    int solvest=*(g.solves.begin());
    for(int i=1;i<=N;i++)
    {
        cout<<((solvest>>(i-1))&1)<<' ';
    }
    return 0;
}