import requests
import json
import time
from hashlib import md5

board = None
n = None
m = None
remainb, remaing, gstatus = None, None, None

URL = "https://prob12-q9h3r8ka.geekgame.pku.edu.cn/"

RTIMES = 0

req = requests.Session()

RAW = ""


def getboard(txt=None):
    global board, n, m
    global remainb, remaing, gstatus
    global RAW
    if txt is None:
        txt = req.get(URL+"/get_board").text
    RAW = txt
    obj = json.loads(txt)
    typ = obj["type"]
    if board is None:
        assert typ == 0
    n, m = obj['sizex'], obj['sizey']
    remainb, remaing = obj['remainb'], obj['remaing']
    gstatus = obj['status']
    if "flag" in obj:
        print("flag:", obj["flag"])
    if typ == 0:
        xb = obj["board"]
        board = [list(x) for x in xb]
    elif typ == 1:
        diff = obj["board"]
        for x in diff:
            board[x[0]][x[1]] = x[2]
    else:
        assert False
    hashed=md5(("".join(["".join(x) for x in board])).encode()).hexdigest()
    if hashed != obj["hash"]:
        print("HASH ERROR")
        return getboard()
    return board


def doopen(x, y):
    global RTIMES
    if board[x][y] != ".":
        return
    RTIMES += 1
    r = req.post(URL+"/open", data={"x": x, "y": y})
    ret=getboard(r.text)
    assert ret[x][y] != "."
    return ret


def dodetect(times=1):
    global RTIMES
    RTIMES += 1
    r = req.post(URL+"/detect", data={"times": times})
    return getboard(r.text)


def printinfo():
    print(n, m, remainb, remaing, gstatus)


getboard()
printinfo()

cons = n//21
assert n % 21 == 5
nvar = 18

doopen(0, 0)
printinfo()

constriants = []

for i in range(0, cons):
    nc = []
    for j in range(3):
        print(i, j)
        curx = 8+21*i+j*6
        cuv = None
        for k in range(nvar):
            cury = 8+6*k
            doopen(curx, cury)
            hgate = (board[curx+1][cury] == '2')
            if hgate:
                cuv = k
                break
        assert cuv is not None
        doopen(curx+1, 8+6*nvar+2)
        hnot = (board[curx+1][8+6*nvar+2] == '1')
        nc.append((cuv, hnot))
    print(nc)
    constriants.append(nc)
    printinfo()

ansc = None

for st in range(2**nvar):
    cun = []
    for i in range(nvar):
        cun.append((st >> i) & 1)
    flag = True
    for nc in constriants:
        nf = False
        for x in nc:
            tv = cun[x[0]]
            if x[1]:
                tv ^= 1
            nf = nf or tv
        flag = flag and nf
        if not flag:
            break
    if flag:
        # print(cun)
        assert ansc is None
        ansc = cun
        # break

print(ansc)

for i in range(nvar):
    cury = 5+6*i
    curx = 3
    if ansc[i]:
        curx += 1
    print(i)
    doopen(curx, cury)


def process3select(midx, midy, a, b):
    # a=1 b=1: **6
    # a=0 b=1: *5*
    # a=1 b=0: *5*
    # a=0 b=0: 6**
    male = int(a)+int(b)
    doopen(midx, midy-1+male)
    print(a,b,midx,midy-1+male)


def processcenter(midx, midy, a, b):
    c = a | b
    if not c:
        doopen(midx, midy+1)
    if not(a and b):
        doopen(midx-1, midy)
    doopen(midx, midy)


for i in range(cons):
    nc = constriants[i]
    print(nc, ansc[nc[0][0]], ansc[nc[1][0]], ansc[nc[2][0]])
    for h in range(3):
        curx = 11+21*i+h*6
        cury = 8+6*nvar-2
        if ansc[nc[h][0]]:
            cury -= 1
        print(i, h)
        doopen(curx, cury)
        doopen(curx, 8+6*nvar-4)
    curx = 7+21*i
    cury = 8+6*nvar+12
    v1 = ansc[nc[0][0]] ^ nc[0][1]
    v2 = ansc[nc[1][0]] ^ nc[1][1]
    v3 = ansc[nc[2][0]] ^ nc[2][1]
    print(v1, v2, v3)
    process3select(curx, cury, v1, v2)
    # processcenter(curx+4, cury-2, v1, v2)
    cury += 12
    process3select(curx, cury, v1 | v2, v3)
    # doopen(curx+4, cury-4)
    # if v1 | v2:
    #     doopen(curx+4, cury-3)
    # else:
    #     doopen(curx+4, cury-5)

for i in range(1000):
    st = time.time()
    bd = dodetect(10)  # 服务器太卡了
    et = time.time()
    print(et-st)
    o = json.loads(RAW)
    if o["type"] == 1 and len(o["board"]) == 0:
        break

print("FIN1")

for i in range(cons):
    nc = constriants[i]
    curx = 7+21*i
    cury = 8+6*nvar+12
    v1 = ansc[nc[0][0]] ^ nc[0][1]
    v2 = ansc[nc[1][0]] ^ nc[1][1]
    v3 = ansc[nc[2][0]] ^ nc[2][1]
    processcenter(curx+4, cury-2, v1, v2)
    cury += 12
    doopen(curx+4, cury-4)
    if v1 | v2:
        doopen(curx+4, cury-3)
    else:
        doopen(curx+4, cury-5)

for i in range(1000):
    st = time.time()
    bd = dodetect(10)
    et = time.time()
    print(et-st)
    o = json.loads(RAW)
    if o["type"] == 1 and len(o["board"]) == 0:
        break

print(RTIMES)
