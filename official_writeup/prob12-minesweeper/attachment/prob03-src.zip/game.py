import random
from genboard import Board
from hashlib import md5


class Game:
    NEARS = [(-1, -1), (-1, 0), (-1, 1), (0, -1),
             (0, 1), (1, -1), (1, 0), (1, 1)]

    def __init__(self, board=None, config=None):
        if board is not None:
            self.import_board(board)
        elif config is not None:
            self.gen_config(config)
        else:
            self.gen()
        self.status = 0  # 0:playing 1:win -1:lose
        self.opened = set()
        self.detected = set()
        self.flags = set()
        self.lboard = None

    def gen_number(self):
        for i in range(len(self.board)):
            for j in range(len(self.board[i])):
                if self.board[i][j] == -1:
                    continue
                for di, dj in self.NEARS:
                    if 0 <= i+di < len(self.board) and 0 <= j+dj < len(self.board[i]) and self.board[i+di][j+dj] == -1:
                        self.board[i][j] += 1

    def gen(self):
        bd = Board()
        bd.gen()
        # add try
        self.import_board(bd.toStr())

    def gen_config(self, config):
        x, y, bombs = config
        self.bombs = []
        self.board = []
        self.size = (x, y)
        for i in range(x):
            self.board.append([])
            for j in range(y):
                self.board[i].append(0)

        for i in range(bombs):
            while True:
                tx = random.randint(0, x-1)
                ty = random.randint(0, y-1)
                if self.board[tx][ty] == 0:
                    self.board[tx][ty] = -1
                    self.bombs.append((x, y))
                    break
        self.gen_number()

    def import_board(self, board):
        self.bombs = []
        self.board = []
        self.size = (len(board), len(board[0]))
        for i in range(len(board)):
            self.board.append([])
            assert len(board[i]) == len(board[0])
            for j in range(len(board[i])):
                if board[i][j] == '*':
                    self.bombs.append((i, j))
                    self.board[i].append(-1)
                else:
                    self.board[i].append(0)
        self.gen_number()

    def open(self, x, y):
        if self.status != 0:
            return
        if (x, y) in self.opened:
            return
        q = [(x, y)]
        while len(q) > 0:
            x, y = q.pop()
            if not (0 <= x < len(self.board) and 0 <= y < len(self.board[x])):
                continue
            self.opened.add((x, y))
            if self.board[x][y] == -1:
                self.status = -1
                continue
            if self.board[x][y] != 0:
                continue
            for di, dj in self.NEARS:
                if 0 <= x+di < len(self.board) and 0 <= y+dj < len(self.board[x]) and (x+di, y+dj) not in self.opened and (x+di, y+dj) not in q:
                    q.append((x+di, y+dj))

    def opens(self, x, y):
        if self.status != 0:
            return self.user_obj()
        self.open(x, y)
        if self.status == 0 and len(self.flags) == len(self.bombs):
            self.status = 1
        return self.user_obj()

    def detect(self):
        if self.status != 0:
            return
        # find where can flag
        flags = set()
        delt = self.opened-self.detected
        # for i in range(len(self.board)):
        #     for j in range(len(self.board[i])):
        for i, j in delt:
            # if (i, j) not in self.opened:
            #     continue
            if not (0 <= i < len(self.board) and 0 <= j < len(self.board[i])):
                print("sanity check failed", i, j)
                continue
            if self.board[i][j] == -1 or self.board[i][j] == 0:
                self.detected.add((i, j))
                continue
            # check bomb count==covered count
            covered_count = 0
            for di, dj in self.NEARS:
                if 0 <= i+di < len(self.board) and 0 <= j+dj < len(self.board[i]):
                    if (i+di, j+dj) not in self.opened:
                        covered_count += 1
            if covered_count == self.board[i][j]:
                self.detected.add((i, j))
                for di, dj in self.NEARS:
                    if 0 <= i+di < len(self.board) and 0 <= j+dj < len(self.board[i]):
                        if (i+di, j+dj) not in self.opened:
                            flags.add((i+di, j+dj))

        # find where can open
        opens = set()
        # for i in range(len(self.board)):
        #     for j in range(len(self.board[i])):
        for i, j in delt:
            # if (i, j) not in self.opened:
            #     continue
            if self.board[i][j] == -1 or self.board[i][j] == 0:
                self.detected.add((i, j))
                continue
            # check bomb count==flag count
            flag_count = 0
            for di, dj in self.NEARS:
                if 0 <= i+di < len(self.board) and 0 <= j+dj < len(self.board[i]):
                    if (i+di, j+dj) in self.flags:
                        flag_count += 1
            if flag_count == self.board[i][j]:
                self.detected.add((i, j))
                for di, dj in self.NEARS:
                    if 0 <= i+di < len(self.board) and 0 <= j+dj < len(self.board[i]):
                        if (i+di, j+dj) not in self.opened and (i+di, j+dj) not in self.flags:
                            opens.add((i+di, j+dj))

        self.flags |= flags
        for x, y in opens:
            self.open(x, y)

    def detects(self, dtimes=1):
        if self.status != 0:
            return self.user_obj()
        lf, lo = len(self.flags), len(self.opened)
        dtimes = min(dtimes, 10)
        for i in range(dtimes):
            self.detect()
            if self.status == 0 and len(self.flags) == len(self.bombs):
                self.status = 1
            if lf == len(self.flags) and lo == len(self.opened):
                break
        return self.user_obj()

    def user_board(self):
        xr = []
        for i in range(len(self.board)):
            ret = ''
            for j in range(len(self.board[i])):
                if (i, j) in self.opened:
                    if self.board[i][j] == -1:
                        ret += '*'
                    else:
                        ret += str(self.board[i][j])
                elif (i, j) in self.flags:
                    ret += 'F'
                else:
                    ret += '.'
            xr.append(ret)
        return xr

    def diff_board(self, lboard, cboard):
        xr = []
        for i in range(len(cboard)):
            for j in range(len(cboard[i])):
                if lboard[i][j] != cboard[i][j]:
                    xr.append((i, j, cboard[i][j]))
        return xr

    def user_obj(self, force=False):
        cboard = self.user_board()
        hashed = md5(("".join(cboard)).encode()).hexdigest()
        # print(self.admin_str())
        ret = {"status": self.status, "remainb": len(self.bombs)-len(self.flags), "remaing": self.size[0]*self.size[1]-len(
            self.opened)-len(self.flags), "sizex": self.size[0], "sizey": self.size[1], "hash": hashed}
        if self.lboard is None or force:
            ret["type"] = 0
            ret["board"] = cboard
        else:
            diffs = self.diff_board(self.lboard, cboard)
            usediff = len(diffs) < len(cboard)*len(cboard[0])//16
            if usediff:
                ret["type"] = 1
                ret["board"] = diffs
            else:
                ret["type"] = 0
                ret["board"] = cboard
        if self.status == 1:
            ret["flag"] = open("flag").read()
        self.lboard = cboard
        return ret

    def admin_str(self):
        xr = []
        for i in range(len(self.board)):
            ret = ''
            for j in range(len(self.board[i])):
                if self.board[i][j] == -1:
                    ret += '*'
                else:
                    ret += str(self.board[i][j])
            xr.append(ret)
        return xr

    def admin_board(self):
        xr = []
        for i in range(len(self.board)):
            ret = ''
            for j in range(len(self.board[i])):
                if self.board[i][j] == -1:
                    ret += '*'
                else:
                    ret += str(self.board[i][j])
            xr.append(ret)
        return xr

    def admin_obj(self):
        ret = {"board": self.admin_board(), "status": self.status, "remainb": len(self.bombs)-len(self.flags),
               "remaing": self.size[0]*self.size[1]-len(self.opened)-len(self.flags), "sizex": self.size[0], "sizey": self.size[1], "type": 0}
        return ret
