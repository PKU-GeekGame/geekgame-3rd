#thanks to https://github.com/DavidNHill/JSMinesweeper

from flask import Flask,request,render_template
import json
from game import Game
import time
import traceback
import threading
lock = threading.Lock()

app = Flask("mine")

GAME=None
ltime=0

INTERVAL=10

def restartGame():
    global GAME,ltime
    if GAME is not None:
        del GAME
    ltime=time.time()
    # GAME=Game(["*...","....","....","...*"])
    # GAME=Game(config=(16,16,40))
    # GAME=Game(config=(160,300,2000))
    for i in range(10):
        try:
            tmp=Game()
            break
        except:
            pass
    GAME=tmp

@app.route('/',methods=["GET"])
def index():
    return render_template('index.html')

@app.route('/get_board',methods=["GET"])
def get_board():
    with lock:
        return json.dumps(GAME.user_obj(True))
    # return json.dumps(GAME.admin_obj())

@app.route('/open',methods=["POST"])
def open():
    with lock:
        try:
            btime=time.time()
            x=int(request.form["x"])
            y=int(request.form["y"])
            print("open",x,y)
            obj=GAME.opens(x,y)
            print("open",x,y,time.time()-btime)
            return json.dumps(obj)
        except Exception as e:
            print(repr(e))
            traceback.print_exc()
            return {"status":"error","msg":"invalid request"}

@app.route('/detect',methods=["POST"])
def detect():
    with lock:
        try:
            dtimes=int(request.form.get("times",1))
            btime=time.time()
            print("detect",dtimes)
            obj=GAME.detects(dtimes)
            print("detect",dtimes,time.time()-btime)
            return json.dumps(obj)
        except Exception as e:
            print(repr(e))
            traceback.print_exc()
            return {"status":"error","msg":"invalid request"}

@app.route('/restart',methods=["POST"])
def restart():
    with lock:
        if time.time()-ltime<INTERVAL:
            return {"status":"error","msg":"too fast,please retry after "+str(int(INTERVAL-(time.time()-ltime)))+" seconds"}
        restartGame()
        return {"status":"ok","data":GAME.user_obj()}

restartGame()

app.run(host="0.0.0.0",port=8080,debug=False,threaded=True)#!!!